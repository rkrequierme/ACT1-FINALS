package com.example.act1finals

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
