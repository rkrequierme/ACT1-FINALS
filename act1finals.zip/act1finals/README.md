// lib/main.dart
import 'package:flutter/material.dart';

void main() {
runApp(const ProductDemoApp());
}


class AuthService {
AuthService._private();
static final AuthService instance = AuthService._private();

final List<User> _users = [];
User? currentUser;

bool register(String username, String password) {
if (_users.any((u) => u.username == username)) return false;
_users.add(User(username: username, password: password));
return true;
}

bool login(String username, String password) {
final user = _users.firstWhere(
(u) => u.username == username && u.password == password,
orElse: () => User.empty());
if (user.isEmpty) return false;
currentUser = user;
return true;
}

void logout() {
currentUser = null;
}
}

class ProductService {
ProductService._private();
static final ProductService instance = ProductService._private();

final List<Product> products = [];
}

class User {
final String username;
final String password;
const User({required this.username, required this.password});

const User.empty() : username = '', password = '';

bool get isEmpty => username.isEmpty && password.isEmpty;
}

class Product {
final String name;
final String description;
Product({required this.name, required this.description});
}

class ProductDemoApp extends StatelessWidget {
const ProductDemoApp({super.key});

@override
Widget build(BuildContext context) {
return MaterialApp(
title: 'Product App Demo',
theme: ThemeData(primarySwatch: Colors.blue),
initialRoute: '/login',
routes: {
'/login': (context) => const LoginScreen(),
'/register': (context) => const RegisterScreen(),
'/menu': (context) => const MenuScreen(),
'/add': (context) => const AddProductScreen(),
'/list': (context) => const ProductListScreen(),
},
);
}
}

/// -------------------- Login Screen --------------------
class LoginScreen extends StatefulWidget {
const LoginScreen({super.key});

@override
State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
final _formKey = GlobalKey<FormState>();
final TextEditingController _usernameC = TextEditingController();
final TextEditingController _passwordC = TextEditingController();
String? _error;

void _tryLogin() {
if (!_formKey.currentState!.validate()) return;

final ok = AuthService.instance
.login(_usernameC.text.trim(), _passwordC.text.trim());

if (ok) {
setState(() => _error = null);
Navigator.pushReplacementNamed(context, '/menu');
} else {
setState(() => _error = 'Invalid username or password.');
}
}

@override
void dispose() {
_usernameC.dispose();
_passwordC.dispose();
super.dispose();
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(title: const Text('Login')),
body: Center(
child: Card(
margin: const EdgeInsets.all(24),
child: Padding(
padding: const EdgeInsets.all(16),
child: SizedBox(
width: 420,
child: Form(
key: _formKey,
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
const Text('Welcome — Please login',
style: TextStyle(fontSize: 18)),
const SizedBox(height: 12),
TextFormField(
controller: _usernameC,
decoration: const InputDecoration(labelText: 'Username'),
validator: (v) =>
v == null || v.trim().isEmpty ? 'Required' : null,
),
const SizedBox(height: 8),
TextFormField(
controller: _passwordC,
decoration: const InputDecoration(labelText: 'Password'),
obscureText: true,
validator: (v) =>
v == null || v.isEmpty ? 'Required' : null,
),
const SizedBox(height: 12),
if (_error != null)
Text(_error!,
style: const TextStyle(color: Colors.red)),
Row(
mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
TextButton(
onPressed: () {
Navigator.pushNamed(context, '/register');
},
child: const Text('Create account'),
),
ElevatedButton(
onPressed: _tryLogin,
child: const Text('Login'),
),
],
),
],
),
),
),
),
),
),
);
}
}

/// -------------------- Register Screen --------------------
class RegisterScreen extends StatefulWidget {
const RegisterScreen({super.key});

@override
State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
final _formKey = GlobalKey<FormState>();
final TextEditingController _usernameC = TextEditingController();
final TextEditingController _passwordC = TextEditingController();
String? _message;

void _tryRegister() {
if (!_formKey.currentState!.validate()) return;

final success = AuthService.instance
.register(_usernameC.text.trim(), _passwordC.text.trim());

if (success) {
setState(() {
_message = 'Registration successful. You can now login.';
});
Future.delayed(const Duration(milliseconds: 800), () {
if (!mounted) return;
Navigator.pop(context);
});
} else {
setState(() {
_message = 'Username already exists. Choose another.';
});
}
}

@override
void dispose() {
_usernameC.dispose();
_passwordC.dispose();
super.dispose();
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(title: const Text('Register')),
body: Center(
child: Card(
margin: const EdgeInsets.all(24),
child: Padding(
padding: const EdgeInsets.all(16),
child: SizedBox(
width: 420,
child: Form(
key: _formKey,
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
const Text('Create an account',
style: TextStyle(fontSize: 18)),
const SizedBox(height: 12),
TextFormField(
controller: _usernameC,
decoration: const InputDecoration(labelText: 'Username'),
validator: (v) =>
v == null || v.trim().isEmpty ? 'Required' : null,
),
const SizedBox(height: 8),
TextFormField(
controller: _passwordC,
decoration: const InputDecoration(labelText: 'Password'),
obscureText: true,
validator: (v) => (v == null || v.length < 4)
? 'Password must be >= 4 chars'
: null,
),
const SizedBox(height: 12),
if (_message != null)
Text(_message!,
style: const TextStyle(color: Colors.green)),
Row(
mainAxisAlignment: MainAxisAlignment.end,
children: [
TextButton(
onPressed: () => Navigator.pop(context),
child: const Text('Back'),
),
ElevatedButton(
onPressed: _tryRegister,
child: const Text('Register'),
),
],
)
],
),
),
),
),
),
),
);
}
}

/// -------------------- Menu Screen --------------------
class MenuScreen extends StatefulWidget {
const MenuScreen({super.key});

@override
State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
String get username =>
AuthService.instance.currentUser?.username ?? 'Unknown user';

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(
title: const Text('Menu'),
actions: [
IconButton(
tooltip: 'Logout',
icon: const Icon(Icons.exit_to_app),
onPressed: () {
AuthService.instance.logout();
Navigator.pushReplacementNamed(context, '/login');
},
)
],
),
body: Center(
child: SizedBox(
width: 420,
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
Text('Hello, $username',
style: const TextStyle(fontSize: 20),
textAlign: TextAlign.center),
const SizedBox(height: 18),
ElevatedButton.icon(
icon: const Icon(Icons.add),
label: const Text('Add New Product'),
onPressed: () => Navigator.pushNamed(context, '/add'),
),
const SizedBox(height: 12),
ElevatedButton.icon(
icon: const Icon(Icons.list),
label: const Text('List Products'),
onPressed: () => Navigator.pushNamed(context, '/list'),
),
const SizedBox(height: 12),
ElevatedButton.icon(
icon: const Icon(Icons.delete_forever),
label: const Text('Clear All Products'),
style: ElevatedButton.styleFrom(
backgroundColor: Colors.red,
),
onPressed: () {
ProductService.instance.products.clear();
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('All products cleared')),
);
setState(() {});
},
),
],
),
),
),
);
}
}

/// -------------------- Add Product Screen --------------------
class AddProductScreen extends StatefulWidget {
const AddProductScreen({super.key});

@override
State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
final _formKey = GlobalKey<FormState>();
final TextEditingController _nameC = TextEditingController();
final TextEditingController _descC = TextEditingController();

void _save() {
if (!_formKey.currentState!.validate()) return;

final product = Product(name: _nameC.text.trim(), description: _descC.text.trim());
ProductService.instance.products.add(product);

ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Product added')),
);

_nameC.clear();
_descC.clear();
}

@override
void dispose() {
_nameC.dispose();
_descC.dispose();
super.dispose();
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(title: const Text('Add Product')),
body: Center(
child: Card(
margin: const EdgeInsets.all(16),
child: Padding(
padding: const EdgeInsets.all(16),
child: SizedBox(
width: 480,
child: Form(
key: _formKey,
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextFormField(
controller: _nameC,
decoration: const InputDecoration(labelText: 'Product Name'),
validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
),
const SizedBox(height: 8),
TextFormField(
controller: _descC,
decoration: const InputDecoration(labelText: 'Description'),
minLines: 1,
maxLines: 3,
),
const SizedBox(height: 12),
Row(
mainAxisAlignment: MainAxisAlignment.end,
children: [
TextButton(
onPressed: () => Navigator.pop(context),
child: const Text('Back'),
),
ElevatedButton(
onPressed: _save,
child: const Text('Save'),
)
],
)
],
),
),
),
),
),
),
);
}
}

/// -------------------- Product List Screen --------------------
class ProductListScreen extends StatefulWidget {
const ProductListScreen({super.key});

@override
State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
void _removeAt(int index) {
final removed = ProductService.instance.products.removeAt(index);
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(content: Text('Removed: ${removed.name}')),
);
setState(() {});
}

@override
Widget build(BuildContext context) {
final products = ProductService.instance.products;

return Scaffold(
appBar: AppBar(title: const Text('Products')),
body: products.isEmpty
? const Center(child: Text('No products yet. Add one from the menu.'))
: ListView.builder(
padding: const EdgeInsets.all(8),
itemCount: products.length,
itemBuilder: (context, index) {
final p = products[index];
return Dismissible(
key: ValueKey(p.hashCode + index),
direction: DismissDirection.endToStart,
background: Container(
color: Colors.red,
alignment: Alignment.centerRight,
padding: const EdgeInsets.symmetric(horizontal: 16),
child: const Icon(Icons.delete, color: Colors.white),
),
onDismissed: (_) => _removeAt(index),
child: Card(
child: ListTile(
title: Text(p.name),
subtitle: Text(p.description),
trailing: IconButton(
icon: const Icon(Icons.delete_forever, color: Colors.red),
onPressed: () => _removeAt(index),
),
),
),
);
},
),
);
}
}