import 'package:flutter/material.dart';

void main() {
  runApp(const ProductDemoApp());
}

/// -------------------- AUTH SERVICE --------------------
class AuthService {
  AuthService._private();
  static final AuthService instance = AuthService._private();

  final List<User> _users = [];
  User? currentUser;

  bool register(String username, String password) {
    if (_users.any((u) => u.username == username)) return false;
    _users.add(User(username: username, password: password));
    return true;
  }

  bool login(String username, String password) {
    final user = _users.firstWhere(
          (u) => u.username == username && u.password == password,
      orElse: () => const User.empty(),
    );
    if (user.isEmpty) return false;
    currentUser = user;
    return true;
  }

  void logout() => currentUser = null;
}

/// -------------------- PRODUCT SERVICE --------------------
class ProductService {
  ProductService._private();
  static final ProductService instance = ProductService._private();

  final List<Product> products = [];
  final List<CartItem> cart = [];

  double get totalPrice =>
      cart.fold(0.0, (sum, item) => sum + (item.product.price * item.quantity));

  void addToCart(Product product) {
    final idx = cart.indexWhere((c) => identical(c.product, product));
    if (idx >= 0) {
      final existing = cart[idx];
      if (existing.quantity < product.stock) {
        existing.quantity++;
      }
    } else {
      if (product.stock > 0) {
        cart.add(CartItem(product: product, quantity: 1));
      }
    }
  }

  void removeFromCart(CartItem item) {
    cart.remove(item);
  }

  void changeQuantity(CartItem item, int newQty) {
    if (newQty <= 0) {
      removeFromCart(item);
      return;
    }
    if (newQty <= item.product.stock) {
      item.quantity = newQty;
    }
  }

  void clearCart() => cart.clear();

  /// Returns true if buy succeeded; false if any item has insufficient stock
  bool buyAll() {
    for (final item in cart) {
      if (item.quantity > item.product.stock) {
        return false;
      }
    }

    for (final item in cart) {
      item.product.stock -= item.quantity;
    }

    clearCart();
    return true;
  }

  void replenishStock(Product product, int amount) {
    if (amount > 0) {
      product.stock += amount;
    }
  }
}

/// -------------------- MODELS --------------------
class User {
  final String username;
  final String password;
  const User({required this.username, required this.password});
  const User.empty() : username = '', password = '';
  bool get isEmpty => username.isEmpty && password.isEmpty;
}

class Product {
  final String name;
  final String description;
  double price;
  int stock;

  Product({
    required this.name,
    required this.description,
    required this.price,
    required this.stock,
  });
}

class CartItem {
  final Product product;
  int quantity;
  CartItem({required this.product, required this.quantity});
}

/// -------------------- APP --------------------
class ProductDemoApp extends StatelessWidget {
  const ProductDemoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Product Cart Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegisterScreen(),
        '/menu': (context) => const MenuScreen(),
        '/add': (context) => const AddProductScreen(),
        '/list': (context) => const ProductListScreen(),
        '/cart': (context) => const CartScreen(),
      },
    );
  }
}

/// -------------------- LOGIN SCREEN --------------------
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameC = TextEditingController();
  final _passwordC = TextEditingController();
  String? _error;

  void _tryLogin() {
    if (!_formKey.currentState!.validate()) return;
    final ok = AuthService.instance
        .login(_usernameC.text.trim(), _passwordC.text.trim());
    if (ok) {
      Navigator.pushReplacementNamed(context, '/menu');
    } else {
      setState(() => _error = 'Invalid username or password.');
    }
  }

  @override
  void dispose() {
    _usernameC.dispose();
    _passwordC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Center(
        child: SizedBox(
          width: 420,
          child: Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextFormField(
                    controller: _usernameC,
                    decoration: const InputDecoration(labelText: 'Username'),
                    validator: (v) =>
                    v == null || v.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _passwordC,
                    decoration: const InputDecoration(labelText: 'Password'),
                    obscureText: true,
                    validator: (v) =>
                    v == null || v.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 8),
                  if (_error != null)
                    Text(_error!, style: const TextStyle(color: Colors.red)),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                          onPressed: () =>
                              Navigator.pushNamed(context, '/register'),
                          child: const Text('Register')),
                      ElevatedButton(
                          onPressed: _tryLogin, child: const Text('Login')),
                    ],
                  )
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// -------------------- REGISTER SCREEN --------------------
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameC = TextEditingController();
  final _passwordC = TextEditingController();
  String? _message;

  void _tryRegister() {
    if (!_formKey.currentState!.validate()) return;
    final ok = AuthService.instance
        .register(_usernameC.text.trim(), _passwordC.text.trim());
    setState(() {
      _message = ok
          ? 'Registration successful. You can now login.'
          : 'Username already exists.';
    });
    if (ok) {
      Future.delayed(const Duration(seconds: 1), () {
        if (!mounted) return;
        Navigator.pop(context);
      });
    }
  }

  @override
  void dispose() {
    _usernameC.dispose();
    _passwordC.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register')),
      body: Center(
        child: SizedBox(
          width: 420,
          child: Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextFormField(
                    controller: _usernameC,
                    decoration: const InputDecoration(labelText: 'Username'),
                    validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _passwordC,
                    decoration: const InputDecoration(labelText: 'Password'),
                    obscureText: true,
                    validator: (v) =>
                    v == null || v.length < 4 ? 'Min 4 chars' : null,
                  ),
                  const SizedBox(height: 8),
                  if (_message != null)
                    Text(_message!, style: const TextStyle(color: Colors.green)),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Back')),
                      ElevatedButton(
                          onPressed: _tryRegister,
                          child: const Text('Register')),
                    ],
                  )
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// -------------------- MENU SCREEN --------------------
class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final username = AuthService.instance.currentUser?.username ?? 'User';
    return Scaffold(
      appBar: AppBar(
        title: const Text('Menu'),
        actions: [
          IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Logout',
              onPressed: () {
                AuthService.instance.logout();
                Navigator.pushReplacementNamed(context, '/login');
              })
        ],
      ),
      body: Center(
        child: SizedBox(
          width: 420,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Hello, $username', style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              onPressed: () => Navigator.pushNamed(context, '/add'),
              icon: const Icon(Icons.add),
              label: const Text('Add Product'),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () => Navigator.pushNamed(context, '/list'),
              icon: const Icon(Icons.list),
              label: const Text('Product List'),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () => Navigator.pushNamed(context, '/cart'),
              icon: const Icon(Icons.shopping_cart),
              label: const Text('Cart'),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () {
                ProductService.instance.products.clear();
                ProductService.instance.clearCart();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('All products cleared')),
                );
              },
              icon: const Icon(Icons.delete_forever),
              label: const Text('Clear All Products'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            ),
          ]),
        ),
      ),
    );
  }
}

/// -------------------- ADD PRODUCT SCREEN --------------------
class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});
  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameC = TextEditingController();
  final _descC = TextEditingController();
  final _priceC = TextEditingController();
  final _stockC = TextEditingController();

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final product = Product(
      name: _nameC.text.trim(),
      description: _descC.text.trim(),
      price: double.parse(_priceC.text.trim()),
      stock: int.parse(_stockC.text.trim()),
    );
    ProductService.instance.products.add(product);
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Product added')));
    _nameC.clear();
    _descC.clear();
    _priceC.clear();
    _stockC.clear();
  }

  @override
  void dispose() {
    _nameC.dispose();
    _descC.dispose();
    _priceC.dispose();
    _stockC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Product')),
      body: Center(
        child: SizedBox(
          width: 480,
          child: Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextFormField(
                      controller: _nameC,
                      decoration:
                      const InputDecoration(labelText: 'Product Name'),
                      validator: (v) =>
                      v == null || v.trim().isEmpty ? 'Required' : null),
                  const SizedBox(height: 8),
                  TextFormField(
                      controller: _descC,
                      decoration:
                      const InputDecoration(labelText: 'Description'),
                      minLines: 1,
                      maxLines: 3),
                  const SizedBox(height: 8),
                  TextFormField(
                      controller: _priceC,
                      decoration: const InputDecoration(labelText: 'Price'),
                      keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                      validator: (v) =>
                      v == null || double.tryParse(v) == null
                          ? 'Enter valid price'
                          : null),
                  const SizedBox(height: 8),
                  TextFormField(
                      controller: _stockC,
                      decoration: const InputDecoration(labelText: 'Stock'),
                      keyboardType: TextInputType.number,
                      validator: (v) =>
                      v == null || int.tryParse(v) == null
                          ? 'Enter valid stock'
                          : null),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Back')),
                      ElevatedButton(onPressed: _save, child: const Text('Save')),
                    ],
                  )
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// -------------------- PRODUCT LIST SCREEN --------------------
class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});
  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  void _replenish(Product p) async {
    final controller = TextEditingController();
    final amount = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Replenish ${p.name}'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Add stock amount'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final val = int.tryParse(controller.text);
              if (val != null && val > 0) {
                Navigator.pop(ctx, val);
              }
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );

    if (amount != null && amount > 0) {
      setState(() {
        ProductService.instance.replenishStock(p, amount);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Added $amount to ${p.name} stock')),
      );
    }
  }

  void _remove(Product p) {
    setState(() {
      ProductService.instance.products.remove(p);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${p.name} removed from list')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final products = ProductService.instance.products;
    return Scaffold(
      appBar: AppBar(title: const Text('Product List')),
      body: products.isEmpty
          ? const Center(child: Text('No products yet. Add some first.'))
          : ListView.builder(
          padding: const EdgeInsets.all(8),
          itemCount: products.length,
          itemBuilder: (_, i) {
            final p = products[i];
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                title: Text(p.name),
                subtitle: Text(
                    '₱${p.price.toStringAsFixed(2)} | Stock: ${p.stock}\n${p.description}'),
                isThreeLine: true,
                trailing: Wrap(
                  spacing: 6,
                  children: [
                    ElevatedButton(
                      onPressed: p.stock > 0
                          ? () {
                        ProductService.instance.addToCart(p);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                              content:
                              Text('${p.name} added to cart')),
                        );
                        setState(() {});
                      }
                          : null,
                      child: const Text('Buy'),
                    ),
                    OutlinedButton(
                      onPressed: () => _replenish(p),
                      child: const Text('Replenish'),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      tooltip: 'Remove Product',
                      onPressed: () => _remove(p),
                    ),
                  ],
                ),
              ),
            );
          }),
    );
  }
}

/// -------------------- CART SCREEN --------------------
class CartScreen extends StatefulWidget {
  const CartScreen({super.key});
  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  void _inc(CartItem item) {
    if (item.quantity < item.product.stock) {
      setState(() {
        item.quantity++;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Only ${item.product.stock} available for ${item.product.name}')),
      );
    }
  }

  void _dec(CartItem item) {
    setState(() {
      if (item.quantity > 1) {
        item.quantity--;
      } else {
        ProductService.instance.removeFromCart(item);
      }
    });
  }

  void _remove(CartItem item) {
    setState(() {
      ProductService.instance.removeFromCart(item);
    });
  }

  void _checkout() {
    final ok = ProductService.instance.buyAll();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(ok
              ? 'Purchase successful!'
              : 'Purchase failed: Not enough stock')),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final cart = ProductService.instance.cart;
    final total = ProductService.instance.totalPrice;
    return Scaffold(
      appBar: AppBar(title: const Text('Cart')),
      body: cart.isEmpty
          ? const Center(child: Text('Your cart is empty.'))
          : Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: cart.length,
              itemBuilder: (_, i) {
                final item = cart[i];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: ListTile(
                    title: Text(item.product.name),
                    subtitle: Text(
                        '₱${item.product.price.toStringAsFixed(2)} x ${item.quantity} = ₱${(item.product.price * item.quantity).toStringAsFixed(2)}'),
                    trailing: Wrap(spacing: 4, children: [
                      IconButton(
                          icon: const Icon(Icons.remove),
                          onPressed: () => _dec(item)),
                      IconButton(
                          icon: const Icon(Icons.add),
                          onPressed: () => _inc(item)),
                      IconButton(
                          icon:
                          const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _remove(item)),
                    ]),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text('Total: ₱${total.toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ElevatedButton.icon(
                    onPressed: _checkout,
                    icon: const Icon(Icons.check),
                    label: const Text('Checkout')),
              ],
            ),
          )
        ],
      ),
    );
  }
}